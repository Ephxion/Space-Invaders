package spaceinvaders;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class PrincipalTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    boolean cambioNivel() {
        int puntos = 101;

        assertTrue();
    }

    @Test
    void imprimirGano() {
    }

    @Test
    void imprimirPerdio() {
    }

    @Test
    void crearEnemigos() {
    }

    @Test
    void crearMisil() {
    }

    @Test
    void colisiones() {
    }

    @Test
    void limpiar() {
    }
}