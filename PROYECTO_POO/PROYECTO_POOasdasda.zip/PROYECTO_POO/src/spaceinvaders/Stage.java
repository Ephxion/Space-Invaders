package spaceinvaders;


public interface Stage {
    int ANCHO = 800;
    int ALTO = 600;
    int NIVELES = 5;
}
